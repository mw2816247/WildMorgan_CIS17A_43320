/* 
 * File:   main.cpp
 * Author: Morgan Wild
 * Created on 17 February, 1:49 PM
 * Purpose: First Program "Hello World"
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Math, Science, Universal, Conversions, High Dimensioned Arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize the Random Number Seed
    
    //Declare Variables
    
    //Initialize Variables
    
    //Map Inputs to Outputs -> Process
    
    //Display Inputs/Outputs
    cout << "Hello World" << endl;
    
    //Exit the Program - Cleanup
    return 0;
}